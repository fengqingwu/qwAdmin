<template>
<!-- 带搜索的页面 -->
<div class="pageWithSearch">
    <div class="searchBl" v-if="!hideSearch">
        <formInline ref="formSearch" v-if="searchFormConfig" style="width:780px;" :config="searchFormConfig"/>
        <el-button size="mini" type="primary" @click="doSearch" class="fl" icon="el-icon-search">搜索</el-button>
        <el-button size="mini" @click="resetSearch" class="fl" type="danger">清空搜索</el-button>

        <div style="clear:both;"></div>
    </div>
    <div class="mainBl"  :style="{ minHeight: (sidebarHeight- (hideSearch? 0 : 160)) + 'px',marginTop: (hideSearch? '0': '20px')}">    
        <qwToolbar v-if="toolbarConfig" :config="toolbarConfig" @itemClicked="itemClicked"/>
        <qwTable v-if="tableConfig" style="margin-top:20px;" @pageChange="pageChange" @sizeChange="sizeChange" :tableConfig="tableConfig" :tableData="tableData"></qwTable>
    </div> 
    <!-- 新增或编辑 -->
    <dialogForm ref="dialogForm" v-if="dialogFormConfig" :config="dialogFormConfig" @formBtnClicked="formBtnClicked"></dialogForm>
</div>
</template>
<script>
import formInline from "../form/formInline.vue";
import qwToolbar from "../qwToolbar/qwToolbar.vue";
import qwTable from "../formTable/formTable.vue"
import dialogForm from "../modelForm/modelForm.vue"
import { mapState } from "vuex"
import { jsonStringify,jsonParse  } from "../../../utils/json.js";
let that__ = null;
export default {
    components:{
        formInline,
        qwToolbar,
        qwTable,
        dialogForm
    },
    created(){
        that__ = this;
        this.dialogFormConfig = this.addFormConfig;
    },
    props:{
        hideSearch:{
            type: Boolean,
            default(){
                return false
            }
        },
        searchFormConfig:{
            type: Object,
            default(){
                return null
            }
        },
        addFormConfig:{
            type: Object,
            default(){
                return null
            }
        },
        editFormConfig:{
            type: Object,
            default(){
                return null
            }
        },
        delCallback:{
            type: Function,
            default(){
                return ()=>{}
            }
        },
        toolbarConfig:{
            type: Array,
            default(){
                return null
            }
        },
        tableConfig:{
            type: Object,
            default(){
                return null
            }
        },
        tableData:{
            type: Array,
            default(){
                return null
            }
        },
    },
    data(){
        return {
            dialogFormConfig: null,
        }
    },
    computed:{
        ...mapState({
            sidebarHeight: state=> state.app.sidebarHeight
        })
    },
    methods:{        
        itemClicked(data){
            this.$emit("toolbarItemClicked",data);
        },
        showModelForm(config,cb){
            window.that__$$ = this;
            this.dialogFormConfig = jsonParse(jsonStringify(config));
            setTimeout(() => {
                this.dialogFormConfig.qwDialog.dialogVisible = true;
                setTimeout(() => {
                    if('function' == typeof(cb)){
                        cb(this)
                    }
                //     this.resetForm();
                }, 100);
            }, 100);
        },
        closeModelForm(cb=()=>{}){
            this.resetForm(()=>{
               setTimeout(() => {
                this.dialogFormConfig.qwDialog.dialogVisible = false;
                setTimeout(() => {
                    if('function' == typeof(cb)){
                        cb(this)
                    }
                }, 100);
            }, 100);
            })
        },
        clearValidate(){
            let modelForm = this.$refs.dialogForm;
            modelForm.clearValidate();
        },
        setFormData(data){
            for(let attr in data){
                this.$set(this.dialogFormConfig.qwForm.formData,attr,data[attr]); 
            }
        },
        resetForm(cb=()=>{}){
            let dialog = this.$refs.dialogForm;
            if(dialog){
                dialog.resetForm();
                setTimeout(() => {
                    dialog.clearValidate();
                    setTimeout(() => {
                       if('function' == typeof(cb)){
                           cb()
                       }
                    }, 100);
                }, 100);
            }                 
        },
        formBtnClicked(data){
            this.$emit("formBtnClicked",data);
        },
        resetSearch(){
            let formSearch = this.$refs.formSearch;
            if(formSearch){
                formSearch.resetForm();
                setTimeout(() => {
                    this.doSearch();
                }, 300);
            }
        },
        doSearch(){
            this.tableConfig.pageNo =1;
            this.getData();
        },
        pageChange(){
            this.getData();
        },
        sizeChange(){
            this.getData();
        },
        getData(){
            let params = this.hideSearch? {}: this.searchFormConfig.formData;
            params.pageSize = this.tableConfig.pageSize;
            params.pageNo = this.tableConfig.pageNo;
            this.$emit("getList",params);
        },
    }
}
</script>
<style lang="less">
.pageWithSearch{
    .searchBl{
        background: #FFF;
        position: relative;
        box-sizing: border-box;
        padding: 20px 20px 0 20px;
        min-height: 68px;
        .qw_form_box{
            float: left;
        }
        .el-button.fl{
            // float: left;
            transform: translateY(2px);
        }
    }
    .mainBl {
        background: #FFF;
        padding: 10px 20px 20px 20px;
        margin-top: 20px;
        // .el-table__body-wrapper.is-scrolling-none{
        //     min-height: 300px;
        // }
    }
    .el-table__empty-text{
        line-height: 200px;
    }
    .el-table::before{
        display: none;
    }
}
</style>

