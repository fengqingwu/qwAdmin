<template>
<div class="jsRecevicer">
<div class="receBox">
    <input type="file" name="file">     
</div>    
</div>    
</template>
<script>
export default {
    
}
</script>
<style lang="less">
.jsRecevicer{
    .receBox{
        width: 100px;
        height: 100px;
        border: 1px solid #F00;
    }
}
</style>
